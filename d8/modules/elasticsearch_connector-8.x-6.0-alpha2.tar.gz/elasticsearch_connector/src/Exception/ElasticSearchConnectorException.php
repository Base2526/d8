<?php

namespace Drupal\elasticsearch_connector\Exception;

use Drupal\search_api\SearchApiException;

/**
 * Class ElasticSearchConnectorException.
 */
class ElasticSearchConnectorException extends SearchApiException {
}
