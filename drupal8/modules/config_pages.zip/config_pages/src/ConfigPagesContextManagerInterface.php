<?php

namespace Drupal\config_pages;

use Drupal\Component\Plugin\PluginManagerInterface;

/**
 * Provides an interface defining a context manager config page.
 */
interface ConfigPagesContextManagerInterface extends PluginManagerInterface {

}
