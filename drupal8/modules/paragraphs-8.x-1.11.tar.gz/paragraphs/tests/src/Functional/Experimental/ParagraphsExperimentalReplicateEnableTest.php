<?php

namespace Drupal\Tests\paragraphs\Functional\Experimental;

/**
 * Enables replicate module.
 *
 * @group paragraphs
 */

class ParagraphsExperimentalReplicateEnableTest extends ParagraphsExperimentalDuplicateFeatureTest {

  public static $modules = [
    'replicate',
  ];

}
